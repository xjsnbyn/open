#!/bin/sh

export KSROOT=/koolshare
source $KSROOT/scripts/base.sh
eval $(dbus export merlinclash_)
alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'

rm -rf /tmp/upload/clash_script.log
rm -rf /tmp/upload/clash_script.txt
decode_url_link(){
	local link=$1
	local len=$(echo $link | wc -L)
	local mod4=$(($len%4))
	if [ "$mod4" -gt "0" ]; then
		local var="===="
		local newlink=${link}${var:$mod4}
		echo -n "$newlink" | sed 's/-/+/g; s/_/\//g' | base64 -d 2>/dev/null
	else
		echo -n "$link" | sed 's/-/+/g; s/_/\//g' | base64 -d 2>/dev/null
	fi
}
get(){
	a=$(echo $(dbus get $1))
	a=$(echo $(dbus get $1))
	echo $a
}
msec=$(get merlinclash_script_edit_content1)
echo_date "测试脚本是否调用" >> /tmp/upload/clash_script.log
script=$(decode_url_link $msec)

echo -e "$script" > /koolshare/merlinclash/yaml_basic/script.yaml
ln -sf /koolshare/merlinclash/yaml_basic/script.yaml /tmp/upload/clash_script.txt

echo_date "生成script.yaml" >> /tmp/upload/clash_script.log

http_response "$1"